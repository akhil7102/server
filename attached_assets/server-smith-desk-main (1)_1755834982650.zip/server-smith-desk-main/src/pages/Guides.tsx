import { useState } from "react";
import { Search, BookOpen, Server, Puzzle, Wrench, ExternalLink } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const guideCategories = [
  { id: "basics", name: "Basics", icon: Server },
  { id: "plugins", name: "Plugins", icon: Puzzle },
  { id: "mods", name: "Mods", icon: Puzzle },
  { id: "advanced", name: "Advanced", icon: Wrench },
];

const guides = [
  {
    id: 1,
    title: "Setting Up Your First Minecraft Server",
    description: "A complete beginner's guide to creating your first Minecraft server from scratch.",
    category: "basics",
    difficulty: "Beginner",
    readTime: "15 min",
    steps: 8
  },
  {
    id: 2,
    title: "Installing Essential Plugins",
    description: "Learn how to install and configure the most important plugins for your server.",
    category: "plugins",
    difficulty: "Intermediate",
    readTime: "20 min",
    steps: 12
  },
  {
    id: 3,
    title: "Optimizing Server Performance",
    description: "Advanced techniques to improve your server's performance and reduce lag.",
    category: "advanced",
    difficulty: "Advanced",
    readTime: "25 min",
    steps: 15
  },
  {
    id: 4,
    title: "Setting Up Fabric Mod Server",
    description: "Step-by-step guide to create a modded server using Fabric mod loader.",
    category: "mods",
    difficulty: "Intermediate",
    readTime: "30 min",
    steps: 18
  },
  {
    id: 5,
    title: "Forge Server Installation",
    description: "Complete guide to setting up a Minecraft Forge server for modded gameplay.",
    category: "mods",
    difficulty: "Intermediate",
    readTime: "25 min",
    steps: 14
  },
  {
    id: 6,
    title: "Paper vs Spigot: Choosing the Right Platform",
    description: "Understand the differences and choose the best server software for your needs.",
    category: "basics",
    difficulty: "Beginner",
    readTime: "10 min",
    steps: 5
  }
];

export default function Guides() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredGuides = guides.filter(guide => {
    const matchesSearch = guide.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         guide.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || guide.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400";
      case "Intermediate": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400";
      case "Advanced": return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  return (
    <div className="desktop-app-window">
      <div className="px-8 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
              <BookOpen className="w-10 h-10 text-primary" />
              Server Setup Guides
            </h1>
            <p className="text-xl text-muted-foreground">
              Step-by-step tutorials with screenshots to help you build amazing Minecraft servers.
            </p>
          </div>

          {/* Search and Filters */}
          <div className="mb-8 space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                placeholder="Search guides..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 h-12 text-lg"
              />
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap gap-2">
              <Button
                variant={!selectedCategory ? "default" : "outline"}
                onClick={() => setSelectedCategory(null)}
                className="rounded-full"
              >
                All Guides
              </Button>
              {guideCategories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  onClick={() => setSelectedCategory(
                    selectedCategory === category.id ? null : category.id
                  )}
                  className="rounded-full flex items-center gap-2"
                >
                  <category.icon className="w-4 h-4" />
                  {category.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Guides Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGuides.map((guide) => (
              <Card key={guide.id} className="serversmith-card group">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <Badge className={getDifficultyColor(guide.difficulty)}>
                      {guide.difficulty}
                    </Badge>
                    <div className="text-sm text-muted-foreground">
                      {guide.readTime}
                    </div>
                  </div>
                  <CardTitle className="text-xl leading-tight group-hover:text-primary transition-colors">
                    {guide.title}
                  </CardTitle>
                  <CardDescription>
                    {guide.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-sm text-muted-foreground">
                      {guide.steps} steps
                    </div>
                  </div>
                  <Button className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View Guide
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredGuides.length === 0 && (
            <div className="text-center py-16">
              <BookOpen className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No guides found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search terms or category filters.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}