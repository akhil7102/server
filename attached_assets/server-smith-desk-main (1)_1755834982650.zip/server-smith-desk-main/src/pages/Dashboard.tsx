import { Swords, Heart, Users, Pickaxe, Gamepad2, Puzzle, Network } from "lucide-react";
import { FeatureCard } from "@/components/FeatureCard";
import { useNavigate } from "react-router-dom";

const features = [
  {
    title: "Practice PVP or Duels Server Setup",
    description: "Set up competitive PVP dueling servers with advanced combat mechanics and ranked systems.",
    icon: Swords,
    action: "practice-pvp"
  },
  {
    title: "Lifesteal Server Setup Guide",
    description: "Create thrilling lifesteal servers where players can steal hearts and survive intense battles.",
    icon: Heart,
    action: "lifesteal"
  },
  {
    title: "FFA Server Setup Guide",
    description: "Build free-for-all combat servers with custom arenas and respawn systems.",
    icon: Users,
    action: "ffa"
  },
  {
    title: "FFA + Practice Server Setup Guide",
    description: "Combine FFA and practice modes for comprehensive PVP training environments.",
    icon: Swords,
    action: "ffa-practice"
  },
  {
    title: "Survival Server Setup Guide",
    description: "Create enhanced survival experiences with custom features and player protection.",
    icon: Pickaxe,
    action: "survival"
  },
  {
    title: "Bedwars Server Setup Guide",
    description: "Set up popular bed defense games with team mechanics and custom maps.",
    icon: Gamepad2,
    action: "bedwars"
  },
  {
    title: "Mini Games Server Setup Guide",
    description: "Build diverse mini-game servers with multiple game modes and lobby systems.",
    icon: Puzzle,
    action: "minigames"
  },
  {
    title: "Complete Network Setup",
    description: "Full proxy network with lobby, lifesteal, survival, bedwars, FFA, practice, and mini games.",
    icon: Network,
    action: "complete-network"
  }
];

export default function Dashboard() {
  const navigate = useNavigate();

  const handleFeatureClick = (action: string) => {
    // Route all server setup guides to guides page
    navigate("/guides");
  };

  return (
    <div className="desktop-app-window">
      {/* Hero Section */}
      <section className="serversmith-hero px-8 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center mb-6">
            <img 
              src="/lovable-uploads/d31b75ae-8fba-4443-83ce-b6235096f78f.png" 
              alt="ServerSmith Logo" 
              className="w-20 h-20 object-contain"
            />
          </div>
          <h1 className="text-5xl font-bold mb-4 serversmith-glow">
            ServerSmith
          </h1>
        </div>
      </section>

      {/* Features Grid */}
      <section className="px-8 py-16">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">
            Everything You Need to Build Amazing Servers
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature) => (
              <FeatureCard
                key={feature.title}
                title={feature.title}
                description={feature.description}
                icon={feature.icon}
                onClick={() => handleFeatureClick(feature.action)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Quick Stats */}
      <section className="px-8 py-16 bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">100+</div>
              <div className="text-muted-foreground">Step-by-step Guides</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">25+</div>
              <div className="text-muted-foreground">Video Tutorials</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">50+</div>
              <div className="text-muted-foreground">Solved Problems</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}