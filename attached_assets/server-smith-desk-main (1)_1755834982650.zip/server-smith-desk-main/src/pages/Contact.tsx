import { Mail, MessageSquare, Clock } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Contact() {
  const handleEmailClick = () => {
    window.location.href = "mailto:serversmith@gmail.com?subject=ServerSmith Support Request";
  };

  return (
    <div className="desktop-app-window">
      <div className="px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
              <Mail className="w-10 h-10 text-primary" />
              Get in Touch
            </h1>
            <p className="text-xl text-muted-foreground">
              Need help with your server setup? We're here to assist you.
            </p>
          </div>

          {/* Contact Card */}
          <Card className="serversmith-card mb-8">
            <CardHeader className="text-center">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Mail className="w-10 h-10 text-primary" />
              </div>
              <CardTitle className="text-3xl">Email Support</CardTitle>
              <CardDescription className="text-lg">
                Send us your questions and we'll get back to you as soon as possible.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="mb-8">
                <div className="text-2xl font-bold text-primary mb-2">
                  serversmith@gmail.com
                </div>
                <p className="text-muted-foreground">
                  Click the button below to open your email client
                </p>
              </div>
              
              <Button 
                size="lg" 
                onClick={handleEmailClick}
                className="px-8 py-4 text-lg"
              >
                <Mail className="w-5 h-5 mr-2" />
                Send Email
              </Button>
            </CardContent>
          </Card>

          {/* Support Information */}
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <Card className="serversmith-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Clock className="w-6 h-6 text-primary" />
                  Response Time
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  We typically respond to support emails within 24-48 hours during business days.
                  For urgent issues, please include "URGENT" in your subject line.
                </p>
              </CardContent>
            </Card>

            <Card className="serversmith-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <MessageSquare className="w-6 h-6 text-primary" />
                  What to Include
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Detailed description of your issue</li>
                  <li>• Server version and type (Spigot, Paper, etc.)</li>
                  <li>• Screenshots or error logs</li>
                  <li>• Steps you've already tried</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Quick Help */}
          <Card className="serversmith-card">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Before You Contact Us</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-3">
                    <MessageSquare className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Check FAQ</h3>
                  <p className="text-sm text-muted-foreground">
                    Many common questions are answered in our FAQ section.
                  </p>
                </div>
                <div>
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-3">
                    <MessageSquare className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Read Guides</h3>
                  <p className="text-sm text-muted-foreground">
                    Our step-by-step guides cover most setup scenarios.
                  </p>
                </div>
                <div>
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-3">
                    <MessageSquare className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Watch Videos</h3>
                  <p className="text-sm text-muted-foreground">
                    Video tutorials for advanced configurations and troubleshooting.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}