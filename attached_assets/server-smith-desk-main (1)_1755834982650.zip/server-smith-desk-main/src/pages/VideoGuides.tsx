import { Play, Clock, Eye, ExternalLink } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const videoGuides = [
  {
    id: 1,
    title: "BungeeCord Multi-Server Setup",
    description: "Complete tutorial on setting up a BungeeCord network to connect multiple Minecraft servers.",
    thumbnail: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=400&h=225&fit=crop&crop=center",
    duration: "32:15",
    views: "15.2K",
    difficulty: "Advanced",
    category: "Multi-Server"
  },
  {
    id: 2,
    title: "Velocity Proxy Configuration",
    description: "Learn how to set up Velocity, the modern alternative to BungeeCord for server networks.",
    thumbnail: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=225&fit=crop&crop=center",
    duration: "28:45",
    views: "12.8K",
    difficulty: "Advanced",
    category: "Multi-Server"
  },
  {
    id: 3,
    title: "Waterfall Proxy Setup Guide",
    description: "Step-by-step guide to configure Waterfall proxy for optimized multi-server networks.",
    thumbnail: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=400&h=225&fit=crop&crop=center",
    duration: "25:30",
    views: "9.4K",
    difficulty: "Advanced",
    category: "Multi-Server"
  },
  {
    id: 4,
    title: "Advanced Plugin Development",
    description: "Create custom plugins from scratch using Spigot API for advanced server functionality.",
    thumbnail: "https://images.unsplash.com/photo-1587620962725-abab7fe55159?w=400&h=225&fit=crop&crop=center",
    duration: "45:20",
    views: "8.7K",
    difficulty: "Expert",
    category: "Development"
  },
  {
    id: 5,
    title: "Server Performance Optimization",
    description: "Advanced techniques to optimize your server for maximum performance and minimal lag.",
    thumbnail: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=225&fit=crop&crop=center",
    duration: "38:12",
    views: "22.1K",
    difficulty: "Advanced",
    category: "Optimization"
  },
  {
    id: 6,
    title: "Database Integration Guide",
    description: "Connect your Minecraft server to MySQL databases for persistent data storage.",
    thumbnail: "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=400&h=225&fit=crop&crop=center",
    duration: "41:55",
    views: "11.3K",
    difficulty: "Expert",
    category: "Database"
  }
];

export default function VideoGuides() {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Advanced": return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-400";
      case "Expert": return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400";
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-400";
    }
  };

  return (
    <div className="desktop-app-window">
      <div className="px-8 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
              <Play className="w-10 h-10 text-primary" />
              Video Tutorials
            </h1>
            <p className="text-xl text-muted-foreground">
              In-depth video guides for advanced server setups and complex configurations.
            </p>
          </div>

          {/* Featured Video */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold mb-6">Featured Tutorial</h2>
            <Card className="serversmith-card overflow-hidden">
              <div className="md:flex">
                <div className="md:w-1/2">
                  <div className="relative aspect-video bg-muted">
                    <img
                      src={videoGuides[0].thumbnail}
                      alt={videoGuides[0].title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/20">
                      <Button size="lg" className="rounded-full w-16 h-16">
                        <Play className="w-6 h-6" />
                      </Button>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/80 text-white px-2 py-1 rounded text-sm">
                      {videoGuides[0].duration}
                    </div>
                  </div>
                </div>
                <div className="md:w-1/2 p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className={getDifficultyColor(videoGuides[0].difficulty)}>
                      {videoGuides[0].difficulty}
                    </Badge>
                    <Badge variant="outline">{videoGuides[0].category}</Badge>
                  </div>
                  <h3 className="text-2xl font-bold mb-3">{videoGuides[0].title}</h3>
                  <p className="text-muted-foreground mb-4">{videoGuides[0].description}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground mb-6">
                    <div className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      {videoGuides[0].views} views
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {videoGuides[0].duration}
                    </div>
                  </div>
                  <Button className="w-full">
                    <Play className="w-4 h-4 mr-2" />
                    Watch Tutorial
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Video Grid */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-6">All Video Guides</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {videoGuides.slice(1).map((video) => (
                <Card key={video.id} className="serversmith-card overflow-hidden group">
                  <div className="relative aspect-video bg-muted">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button size="lg" className="rounded-full">
                        <Play className="w-5 h-5" />
                      </Button>
                    </div>
                    <div className="absolute bottom-2 right-2 bg-black/80 text-white px-2 py-1 rounded text-sm">
                      {video.duration}
                    </div>
                  </div>
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={getDifficultyColor(video.difficulty)}>
                        {video.difficulty}
                      </Badge>
                      <Badge variant="outline">{video.category}</Badge>
                    </div>
                    <CardTitle className="text-lg leading-tight group-hover:text-primary transition-colors">
                      {video.title}
                    </CardTitle>
                    <CardDescription className="line-clamp-2">
                      {video.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        {video.views} views
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {video.duration}
                      </div>
                    </div>
                    <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Watch Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}