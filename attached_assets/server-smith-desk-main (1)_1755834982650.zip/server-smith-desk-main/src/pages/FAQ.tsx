import { HelpCircle, ChevronDown } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";

const faqData = [
  {
    id: "basic-setup",
    category: "Basic Setup",
    questions: [
      {
        question: "What are the minimum system requirements for a Minecraft server?",
        answer: "For a basic server with 1-10 players, you need at least 2GB RAM, a dual-core CPU, and 10GB of free storage. For larger servers (20+ players), consider 4GB+ RAM and a quad-core CPU. SSD storage is recommended for better performance."
      },
      {
        question: "How do I port forward for my Minecraft server?",
        answer: "Port forwarding involves accessing your router's admin panel (usually 192.168.1.1), finding the port forwarding section, and creating a rule for port 25565 (or your custom port) pointing to your server's local IP address. The exact steps vary by router manufacturer."
      },
      {
        question: "What's the difference between Java and Bedrock servers?",
        answer: "Java Edition servers run on PC/Mac/Linux and support extensive modding and plugins. Bedrock servers support cross-platform play (Mobile, Console, Windows 10) but have limited customization options. Choose based on your target audience."
      }
    ]
  },
  {
    id: "plugins-mods",
    category: "Plugins & Mods",
    questions: [
      {
        question: "What's the difference between Spigot, Paper, and Fabric?",
        answer: "Spigot is a popular server software that supports Bukkit plugins. Paper is a high-performance fork of Spigot with optimizations and bug fixes. Fabric is a lightweight modding platform for both client and server. Choose based on whether you want plugins (Spigot/Paper) or mods (Fabric/Forge)."
      },
      {
        question: "Can I use both plugins and mods on the same server?",
        answer: "Generally, no. Plugins (Bukkit/Spigot) and mods (Forge/Fabric) use different systems. However, some hybrid solutions like Mohist or Magma attempt to support both, but they can be unstable. It's recommended to choose one approach for stability."
      },
      {
        question: "How do I install plugins on my server?",
        answer: "Download the .jar plugin file, place it in your server's 'plugins' folder, restart the server, and configure the plugin settings in its generated config files. Always check plugin compatibility with your server version."
      }
    ]
  },
  {
    id: "advanced",
    category: "Advanced Setup",
    questions: [
      {
        question: "How do I set up a BungeeCord network?",
        answer: "BungeeCord allows multiple servers to be connected through a proxy. Set up multiple Spigot/Paper servers, configure each server's spigot.yml to work with BungeeCord, then configure the BungeeCord proxy to connect them. Players join through the proxy which distributes them to appropriate servers."
      },
      {
        question: "What's the difference between BungeeCord and Velocity?",
        answer: "Velocity is a modern alternative to BungeeCord with better performance, security, and 1.13+ support. It's faster and more stable but requires servers to be 1.13+. BungeeCord has broader compatibility but is older and less optimized."
      },
      {
        question: "How do I optimize my server for better performance?",
        answer: "Key optimizations include: adjusting view-distance and simulation-distance, using Paper instead of Spigot, allocating appropriate RAM (not too much or too little), using optimization plugins like ClearLag, and regularly updating your server software."
      }
    ]
  },
  {
    id: "troubleshooting",
    category: "Troubleshooting",
    questions: [
      {
        question: "Players can't connect to my server, what should I check?",
        answer: "Common issues: 1) Port forwarding not configured correctly, 2) Server not running or crashed, 3) Firewall blocking connections, 4) Wrong IP address or port, 5) Server is full or whitelist is enabled. Check server logs for specific error messages."
      },
      {
        question: "My server is lagging, how can I fix it?",
        answer: "Lag sources: 1) Too many entities (mobs, items), 2) Redstone contraptions, 3) Insufficient RAM, 4) Too many plugins, 5) Chunk loading issues. Use timing reports (/timings on) to identify bottlenecks and optimize accordingly."
      },
      {
        question: "How do I backup my server properly?",
        answer: "Regularly backup your 'world' folders and server configuration files. Use plugins like WorldEdit for in-game backups, or set up automated scripts. Always test your backups by restoring them to ensure they work correctly."
      }
    ]
  }
];

export default function FAQ() {
  return (
    <div className="desktop-app-window">
      <div className="px-8 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4 flex items-center gap-3">
              <HelpCircle className="w-10 h-10 text-primary" />
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-muted-foreground">
              Find answers to common questions about server creation and setup.
            </p>
          </div>

          {/* FAQ Categories */}
          <div className="space-y-8">
            {faqData.map((category) => (
              <Card key={category.id} className="serversmith-card">
                <CardContent className="p-6">
                  <h2 className="text-2xl font-bold mb-6 text-primary">
                    {category.category}
                  </h2>
                  <Accordion type="single" collapsible className="space-y-2">
                    {category.questions.map((faq, index) => (
                      <AccordionItem
                        key={`${category.id}-${index}`}
                        value={`${category.id}-${index}`}
                        className="border border-border rounded-lg px-4"
                      >
                        <AccordionTrigger className="text-left hover:no-underline hover:text-primary transition-colors py-4">
                          <span className="font-medium">{faq.question}</span>
                        </AccordionTrigger>
                        <AccordionContent className="pb-4 text-muted-foreground leading-relaxed">
                          {faq.answer}
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Contact CTA */}
          <Card className="serversmith-card mt-12">
            <CardContent className="p-8 text-center">
              <HelpCircle className="w-16 h-16 text-primary mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-4">Still Need Help?</h3>
              <p className="text-muted-foreground mb-6">
                Can't find the answer you're looking for? Get in touch with our support team.
              </p>
              <a
                href="/contact"
                className="inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
              >
                Contact Support
              </a>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}